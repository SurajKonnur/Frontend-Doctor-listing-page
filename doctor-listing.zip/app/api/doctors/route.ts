import { NextResponse } from "next/server"

// This is a mock API endpoint that would be replaced with your actual API
export async function GET() {
  // In a real implementation, you would fetch data from your provided API
  // const response = await fetch('YOUR_API_ENDPOINT')
  // const data = await response.json()

  // Mock data for demonstration
  const mockDoctors = [
    {
      id: "1",
      name: "Dr. Sarah Johnson",
      specialty: "Cardiology",
      location: "New York, NY",
      rating: 4.9,
      experience: 15,
      availability: ["Today, 2:00 PM", "Today, 4:30 PM", "Tomorrow, 10:00 AM", "Tomorrow, 3:15 PM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["Blue Cross", "Aetna", "UnitedHealthcare"],
    },
    {
      id: "2",
      name: "Dr. Michael Chen",
      specialty: "Dermatology",
      location: "San Francisco, CA",
      rating: 4.7,
      experience: 12,
      availability: ["Tomorrow, 9:00 AM", "Tomorrow, 11:30 AM", "Friday, 2:00 PM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["Medicare", "Kaiser", "Cigna"],
    },
    {
      id: "3",
      name: "Dr. Emily Rodriguez",
      specialty: "Pediatrics",
      location: "Chicago, IL",
      rating: 5.0,
      experience: 8,
      availability: ["Today, 3:15 PM", "Tomorrow, 10:00 AM", "Friday, 1:30 PM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["Humana", "Blue Cross", "Medicaid"],
    },
    {
      id: "4",
      name: "Dr. James Wilson",
      specialty: "Orthopedics",
      location: "Boston, MA",
      rating: 4.5,
      experience: 20,
      availability: ["Friday, 8:00 AM", "Friday, 10:30 AM", "Monday, 2:00 PM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["Aetna", "UnitedHealthcare", "Cigna"],
    },
    {
      id: "5",
      name: "Dr. Lisa Patel",
      specialty: "Neurology",
      location: "Seattle, WA",
      rating: 4.8,
      experience: 14,
      availability: ["Tomorrow, 1:00 PM", "Friday, 9:30 AM", "Monday, 11:00 AM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["Medicare", "Blue Cross", "Kaiser"],
    },
    {
      id: "6",
      name: "Dr. Robert Kim",
      specialty: "Cardiology",
      location: "Los Angeles, CA",
      rating: 4.6,
      experience: 17,
      availability: ["Today, 5:00 PM", "Tomorrow, 2:30 PM", "Friday, 10:00 AM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["Cigna", "Humana", "Aetna"],
    },
    {
      id: "7",
      name: "Dr. Jennifer Taylor",
      specialty: "Family Medicine",
      location: "Denver, CO",
      rating: 4.9,
      experience: 10,
      availability: ["Friday, 3:00 PM", "Monday, 9:30 AM", "Monday, 4:00 PM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["UnitedHealthcare", "Medicare", "Blue Cross"],
    },
    {
      id: "8",
      name: "Dr. David Martinez",
      specialty: "Dermatology",
      location: "Miami, FL",
      rating: 4.7,
      experience: 9,
      availability: ["Tomorrow, 8:00 AM", "Tomorrow, 4:30 PM", "Friday, 11:00 AM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["Medicaid", "Aetna", "Cigna"],
    },
    {
      id: "9",
      name: "Dr. Amanda Lee",
      specialty: "Psychiatry",
      location: "Austin, TX",
      rating: 4.8,
      experience: 11,
      availability: ["Today, 1:00 PM", "Friday, 2:30 PM", "Monday, 10:00 AM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["Blue Cross", "UnitedHealthcare", "Humana"],
    },
    {
      id: "10",
      name: "Dr. Thomas Wright",
      specialty: "Ophthalmology",
      location: "Philadelphia, PA",
      rating: 4.5,
      experience: 16,
      availability: ["Tomorrow, 12:00 PM", "Friday, 9:00 AM", "Monday, 3:30 PM"],
      image: "/placeholder.svg?height=96&width=96",
      insurances: ["Medicare", "Kaiser", "Aetna"],
    },
  ]

  return NextResponse.json(mockDoctors)
}
