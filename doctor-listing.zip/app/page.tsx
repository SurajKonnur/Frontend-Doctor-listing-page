"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Search, Filter, MapPin, Star, ChevronDown } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { Skeleton } from "@/components/ui/skeleton"

interface Doctor {
  id: string
  name: string
  specialty: string
  location: string
  rating: number
  experience: number
  availability: string[]
  image: string
  insurances: string[]
}

export default function DoctorListingPage() {
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({
    specialty: "",
    location: "",
    rating: 0,
    insurance: "",
  })

  // Fetch doctors data
  useEffect(() => {
    const fetchDoctors = async () => {
      try {
        // Replace with the API link provided by the user
        const response = await fetch("/api/doctors")
        const data = await response.json()
        setDoctors(data)
        setFilteredDoctors(data)
        setLoading(false)
      } catch (error) {
        console.error("Error fetching doctors:", error)
        setLoading(false)
      }
    }

    fetchDoctors()
  }, [])

  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value
    setSearchQuery(query)

    if (query.length > 1) {
      // Generate suggestions based on doctor names and specialties
      const nameMatches = doctors
        .filter(
          (doctor) =>
            doctor.name.toLowerCase().includes(query.toLowerCase()) ||
            doctor.specialty.toLowerCase().includes(query.toLowerCase()),
        )
        .map((doctor) => doctor.name)

      const specialtyMatches = [
        ...new Set(
          doctors
            .filter((doctor) => doctor.specialty.toLowerCase().includes(query.toLowerCase()))
            .map((doctor) => doctor.specialty),
        ),
      ]

      setSuggestions([...new Set([...nameMatches, ...specialtyMatches])].slice(0, 5))
      setShowSuggestions(true)
    } else {
      setSuggestions([])
      setShowSuggestions(false)
    }

    // Filter doctors based on search query
    applyFilters(query, filters)
  }

  // Handle suggestion selection
  const handleSelectSuggestion = (suggestion: string) => {
    setSearchQuery(suggestion)
    setShowSuggestions(false)
    applyFilters(suggestion, filters)
  }

  // Handle filter changes
  const handleFilterChange = (key: string, value: string | number) => {
    const newFilters = { ...filters, [key]: value }
    setFilters(newFilters)
    applyFilters(searchQuery, newFilters)
  }

  // Apply all filters and search
  const applyFilters = (query: string, currentFilters: any) => {
    let results = doctors

    // Apply search query
    if (query) {
      results = results.filter(
        (doctor) =>
          doctor.name.toLowerCase().includes(query.toLowerCase()) ||
          doctor.specialty.toLowerCase().includes(query.toLowerCase()),
      )
    }

    // Apply specialty filter
    if (currentFilters.specialty) {
      results = results.filter((doctor) => doctor.specialty === currentFilters.specialty)
    }

    // Apply location filter
    if (currentFilters.location) {
      results = results.filter((doctor) => doctor.location.includes(currentFilters.location))
    }

    // Apply rating filter
    if (currentFilters.rating > 0) {
      results = results.filter((doctor) => doctor.rating >= currentFilters.rating)
    }

    // Apply insurance filter
    if (currentFilters.insurance) {
      results = results.filter((doctor) => doctor.insurances.includes(currentFilters.insurance))
    }

    setFilteredDoctors(results)
  }

  // Reset all filters
  const resetFilters = () => {
    setFilters({
      specialty: "",
      location: "",
      rating: 0,
      insurance: "",
    })
    setSearchQuery("")
    setFilteredDoctors(doctors)
  }

  // Get unique specialties for filter options
  const specialties = [...new Set(doctors.map((doctor) => doctor.specialty))]

  // Get unique locations for filter options
  const locations = [...new Set(doctors.map((doctor) => doctor.location))]

  // Get unique insurances for filter options
  const insurances = [...new Set(doctors.flatMap((doctor) => doctor.insurances))]

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Find a Doctor</h1>

      {/* Search Bar with Autocomplete */}
      <div className="relative mb-8">
        <div className="flex items-center border rounded-lg overflow-hidden bg-white">
          <div className="p-3 text-gray-400">
            <Search className="h-5 w-5" />
          </div>
          <Input
            type="text"
            placeholder="Search by doctor name or specialty..."
            value={searchQuery}
            onChange={handleSearchChange}
            className="flex-1 border-0 focus-visible:ring-0 focus-visible:ring-offset-0"
          />
          <Button className="rounded-l-none">Search</Button>
        </div>

        {/* Autocomplete Suggestions */}
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute z-10 w-full bg-white border rounded-lg mt-1 shadow-lg">
            <ul>
              {suggestions.map((suggestion, index) => (
                <li
                  key={index}
                  className="px-4 py-2 hover:bg-gray-100 cursor-pointer"
                  onClick={() => handleSelectSuggestion(suggestion)}
                >
                  {suggestion}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Filter Panel */}
        <div className="w-full md:w-1/4 mb-6 md:mb-0">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold flex items-center">
                  <Filter className="h-5 w-5 mr-2" />
                  Filters
                </h2>
                <Button variant="ghost" size="sm" onClick={resetFilters} className="text-sm">
                  Reset
                </Button>
              </div>

              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="specialty">
                  <AccordionTrigger>Specialty</AccordionTrigger>
                  <AccordionContent>
                    <Select value={filters.specialty} onValueChange={(value) => handleFilterChange("specialty", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select specialty" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Specialties</SelectItem>
                        {specialties.map((specialty) => (
                          <SelectItem key={specialty} value={specialty}>
                            {specialty}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="location">
                  <AccordionTrigger>Location</AccordionTrigger>
                  <AccordionContent>
                    <Select value={filters.location} onValueChange={(value) => handleFilterChange("location", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Locations</SelectItem>
                        {locations.map((location) => (
                          <SelectItem key={location} value={location}>
                            {location}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="rating">
                  <AccordionTrigger>Rating</AccordionTrigger>
                  <AccordionContent>
                    <Select
                      value={filters.rating.toString()}
                      onValueChange={(value) => handleFilterChange("rating", Number.parseInt(value))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Minimum rating" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">Any Rating</SelectItem>
                        <SelectItem value="3">3+ Stars</SelectItem>
                        <SelectItem value="4">4+ Stars</SelectItem>
                        <SelectItem value="5">5 Stars</SelectItem>
                      </SelectContent>
                    </Select>
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="insurance">
                  <AccordionTrigger>Insurance</AccordionTrigger>
                  <AccordionContent>
                    <Select value={filters.insurance} onValueChange={(value) => handleFilterChange("insurance", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select insurance" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Insurance</SelectItem>
                        {insurances.map((insurance) => (
                          <SelectItem key={insurance} value={insurance}>
                            {insurance}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </div>

        {/* Doctor Listing */}
        <div className="w-full md:w-3/4">
          <div className="flex justify-between items-center mb-4">
            <p className="text-gray-500">{filteredDoctors.length} doctors found</p>
            <Select defaultValue="relevance">
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="relevance">Relevance</SelectItem>
                <SelectItem value="rating">Highest Rating</SelectItem>
                <SelectItem value="experience">Most Experience</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {loading ? (
            // Loading skeletons
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-0">
                    <div className="flex flex-col md:flex-row p-6 gap-4">
                      <Skeleton className="h-24 w-24 rounded-full" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-6 w-1/3" />
                        <Skeleton className="h-4 w-1/4" />
                        <Skeleton className="h-4 w-2/3" />
                        <div className="flex gap-2 mt-2">
                          <Skeleton className="h-8 w-20" />
                          <Skeleton className="h-8 w-20" />
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredDoctors.length > 0 ? (
            <div className="space-y-4">
              {filteredDoctors.map((doctor) => (
                <Card key={doctor.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-0">
                    <div className="flex flex-col md:flex-row p-6 gap-4">
                      <div className="flex-shrink-0">
                        <img
                          src={doctor.image || "/placeholder.svg?height=96&width=96"}
                          alt={doctor.name}
                          className="h-24 w-24 rounded-full object-cover border"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-semibold">{doctor.name}</h3>
                        <p className="text-gray-500">{doctor.specialty}</p>
                        <div className="flex items-center mt-1 text-gray-500">
                          <MapPin className="h-4 w-4 mr-1" />
                          <span className="text-sm">{doctor.location}</span>
                        </div>
                        <div className="flex items-center mt-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < doctor.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                              }`}
                            />
                          ))}
                          <span className="ml-1 text-sm text-gray-500">({doctor.rating})</span>
                        </div>
                        <div className="flex flex-wrap gap-2 mt-3">
                          <Badge variant="outline" className="bg-gray-50">
                            {doctor.experience} years exp
                          </Badge>
                          {doctor.insurances.slice(0, 2).map((insurance) => (
                            <Badge key={insurance} variant="outline" className="bg-gray-50">
                              {insurance}
                            </Badge>
                          ))}
                          {doctor.insurances.length > 2 && (
                            <Badge variant="outline" className="bg-gray-50">
                              +{doctor.insurances.length - 2} more
                            </Badge>
                          )}
                        </div>
                        <div className="flex gap-3 mt-4">
                          <Button size="sm">Book Appointment</Button>
                          <Button size="sm" variant="outline">
                            View Profile
                          </Button>
                        </div>
                      </div>
                      <div className="md:w-1/4 mt-4 md:mt-0">
                        <h4 className="font-medium text-sm mb-2">Next Available</h4>
                        <div className="space-y-2">
                          {doctor.availability.slice(0, 3).map((slot, index) => (
                            <Button key={index} variant="outline" size="sm" className="w-full justify-start">
                              {slot}
                            </Button>
                          ))}
                          {doctor.availability.length > 3 && (
                            <Button variant="ghost" size="sm" className="w-full text-gray-500">
                              More times <ChevronDown className="h-4 w-4 ml-1" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-50 rounded-lg">
              <h3 className="text-xl font-medium mb-2">No doctors found</h3>
              <p className="text-gray-500 mb-4">Try adjusting your search or filter criteria</p>
              <Button onClick={resetFilters}>Reset Filters</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
